package com.example.josue_pc.appmasterv2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class ordenj extends AppCompatActivity {
    Button orden;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ordenes);
        orden=(Button)findViewById(R.id.orden);
        //* Boton para ir a menu principal
        orden.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intento = new Intent(ordenj.this, MainActivity.class);
                startActivity(intento);
            }
        });



    }


}
